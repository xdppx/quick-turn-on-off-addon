# type: ignore
import bpy
import addon_utils

# bl_info = {
#   "name": "Quick turn on/off Addon",
#   "description": "Quick turn on/off Addon",
#   "author": "DPP",
#   "version": (1, 0, 0),
#   "blender": (4, 2, 0),
#   "location": "View3D",
#   "wiki_url": "",
#   "category": "addon" } 

def get_installed_addon(self, context):
  enable_addon = [addon.module for addon in bpy.context.preferences.addons]
  get_installed_addon.items = [
    (mod.__name__, \
    f"        {mod.bl_info.get('name')}" if mod.__name__ not in enable_addon else f"ON-{mod.bl_info.get('name')}", "") \
    for mod in addon_utils.modules() \
    ]
  return get_installed_addon.items
get_installed_addon.items = []
  
class Addon_OT_Toggle2(bpy.types.Operator):
  bl_idname = "addon.toggle"
  bl_label = "Quick turn on/off Addon"
  bl_options = {'REGISTER'}
  bl_property = "items_enum"
    
  # items, modules, enable_addon = get_installed_addon()[:]
  # items_enum = bpy.props.EnumProperty(items=get_installed_addon()[0], name="Addon", default=None)
  items_enum: bpy.props.EnumProperty(name="Addon2", items=get_installed_addon, default=None)
  # items_enum: bpy.props.EnumProperty(name="Addon", items=lambda self, context: fill_item_list(), default=None)

  # def poll(self, context):
    # pass

  def execute(self, context):
    selected_item = self.items_enum
    enable_addon = [addon.module for addon in bpy.context.preferences.addons]
    modules = get_installed_addon(self, context)
    modules_info = {mod[0]: mod[1] for mod in modules}

    if (selected_item in enable_addon ):
      bpy.ops.preferences.addon_disable(module=selected_item)
      self.report({'INFO'}, f"Addon {modules_info[selected_item]} has been turn off!")
    else:
      bpy.ops.preferences.addon_enable(module=selected_item)
      self.report({'INFO'}, f"Addon {modules_info[selected_item]} has been turn on!")
    return {'FINISHED'}

  def invoke(self, context, event):
    wm = context.window_manager
    wm.invoke_search_popup(self)
    return {'FINISHED'}

# class Prefe(bpy.types.AddonPreferences):
#   bl_idname = __name__
#   def draw(self, context):
#     layout = self.layout
#     layout.label(text="Shortcut")
#     # Display keymap in Preferences
#     keymap = bpy.context.window_manager.keyconfigs.addon.keymaps.get('ToggleAddon')
#     if keymap:
#       for kmi in keymap.keymap_items:
#         if kmi.idname == Addon_OT_Toggle.bl_idname:
#           keys = [k for k, v in { "Ctrl": kmi.ctrl,
#                                   "Alt": kmi.alt,
#                                   "Shift": kmi.shift,
#                                   "OSkey": kmi.oskey
#                                 }.items() if v == 1
#           ]
#           layout.label(text="F3: Toggle Addon")
#           layout.label(text=f'{" ".join(keys)} {kmi.type}')
#           break

def add_keymap():
  # Get the keyconfig
  wm = bpy.context.window_manager
  kc = wm.keyconfigs.addon
  if kc:
    km = kc.keymaps.new(name='Toggle Addon', space_type='EMPTY')
    # Define the shortcut
    kmi = km.keymap_items.new(Addon_OT_Toggle2.bl_idname, 'F7', 'PRESS', ctrl=True)

def remove_keymap():
  wm = bpy.context.window_manager
  kc = wm.keyconfigs.addon
  if kc:
    km = kc.keymaps.get('Toggle Addon')
    if km:
      for kmi in km.keymap_items:
        if kmi.idname == Addon_OT_Toggle2.bl_idname:
          km.keymap_items.remove(kmi)
          break

def register():
  bpy.utils.register_class(Addon_OT_Toggle2)
  # bpy.utils.register_class(Prefe)
  add_keymap()
  
def unregister():
  remove_keymap()
  bpy.utils.unregister_class(Addon_OT_Toggle2)
  # bpy.utils.unregister_class(Prefe)

if __name__ == "__main__":
    register()
